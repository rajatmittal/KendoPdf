import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { ProductService } from "./product.service";
declare var kendo: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
 
})
export class AppComponent {
  ngOnInit(){
    
  }
  ngAfterViewInit(){
    alert("abc")
    console.log(document.getElementById('xyz'))
    document.getElementById('xyz')?.click();
  }
  
  
}
