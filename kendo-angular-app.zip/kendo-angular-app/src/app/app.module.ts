import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import '@progress/kendo-angular-pdf-export';
import { PDFExportModule } from '@progress/kendo-angular-pdf-export';

import { AppComponent } from './app.component';
import { PdfTestComponent } from './pdf-test/pdf-test.component';

@NgModule({
  declarations: [
    AppComponent,
    PdfTestComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,PDFExportModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
