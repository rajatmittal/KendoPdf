import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { ProductService } from "./../product.service";
declare var kendo: any;
@Component({
  selector: 'app-pdf-test',
  templateUrl: './pdf-test.component.html',
  styleUrls: ['./pdf-test.component.css'],
  providers: [ProductService]
})
export class PdfTestComponent implements OnInit {
  title = 'kendo-angular-app';
  public data: any;
  @ViewChild("abc") spreadsheetEl!: ElementRef;

  constructor(private hostEl: ElementRef, private service: ProductService) {}

  ngOnInit(): void {
  }
  
  ngAfterViewInit() {
    this.service.getSpreadSheetData().subscribe((res) => {
      this.data = <any>res;
      this.bindSpreadSheet(res);
    });
  }
  bindSpreadSheet(data:any) {
    // var data = JSON.parse(
    //   data1.d.SpreadsheetJsonData["d206f3c1-5ed5-43cc-8151-7e83d737c6f0"]
    //     .JsonData
    // );
    console.log(data);
    var questionColumns = 0;
    var questionRows = 0;
    questionColumns = data.sheets[0].rows[0].cells.length;
    questionRows = data.sheets[0].rows.length;
    var rowsHeight = 0;
    data.sheets[0].rows.forEach(function (item:any) {
      if (item.height == undefined) {
        rowsHeight += 20; //DEFAULT_QUESTION_HEIGHT = 20 has been added to the orginal row height
      } else {
        rowsHeight += item.height;
      }
    });
    var spreadsheet = kendo
      .jQuery(this.spreadsheetEl.nativeElement)
      .kendoSpreadsheet({
        sheetsbar: false,
        columns: questionColumns,
        rows: questionRows,
        toolbar: false,
        formulabar:false
      })
      .data("kendoSpreadsheet");

      this.modifyCells(null, data);

    spreadsheet.fromJSON(data);

    var sheet = spreadsheet.activeSheet();
    spreadsheet._view.editor.cellInput.popup.bind("open", this.formulaPopupHandler);
    var currentCell = kendo.jQuery(
      spreadsheet._view.editor.cellInput.element[0]
    );
    currentCell.bind("keyup", "paste", this.formulaInputHandler);
    this.modifyContextMenu(spreadsheet);
  }
  modifyCells(activesheet:any, data:any) {
    if (
      data != undefined &&
      data != null &&
      data.sheets[0] != undefined &&
      data.sheets[0] != null
    ) {
      var rowIterator = 0;
      if (data.sheets[0].rows != undefined && data.sheets[0].rows != null) {
        rowIterator = data.sheets[0].rows.length;
        if (rowIterator > 0) {
          var columnIterator = 0;
          if (
            data.sheets[0].rows[0].cells != undefined &&
            data.sheets[0].rows[0].cells != null
          ) {
            columnIterator = data.sheets[0].rows[0].cells.length;
          }
          if (columnIterator > 0) {
            for (var row = 0; row < rowIterator; row++) {
              var currentRow = data.sheets[0].rows[row];
              for (var col = 0; col < columnIterator; col++) {
                var cell = currentRow.cells[col];
                if (
                  (!cell.hasOwnProperty("enable") ||
                    (cell.hasOwnProperty("enable") && cell.enable === true)) &&
                  (currentRow.index == 0 ||
                    cell.IsApiCell !== undefined ||
                    cell.hasOwnProperty("formula"))
                ) {
                  cell.enable = false;
                }
              }
            }
          }
        }
      }
    }
  }

  formulaInputHandler(args:any){
   debugger;if (args.children.length > 0) {
      if (args.firstElementChild.innerText === '=') {
          args.innerText = "";
          alert("Entering formula is not allowed in this question.");
      }
  }
  return false;
   }

   formulaPopupHandler(){
     return false;
   }

  modifyContextMenu(spreadsheet:any) {
    //Remove the Row Header context menu
    var rowHeaderContextMenu = spreadsheet.rowHeaderContextMenu();
    rowHeaderContextMenu.destroy();

    //Remove the Column Header context menu
    var colHeaderContextMenu = spreadsheet.colHeaderContextMenu();
    colHeaderContextMenu.destroy();

    //Cell level context menu
    var cellContextMenu = spreadsheet.cellContextMenu();

    //Remove Merge option from the context menu
    cellContextMenu.destroy();
    var formulaBar = spreadsheet.element.children()[0];
    formulaBar.remove();
    spreadsheet.resize();
  }
  ngOnDestroy(): void {
    kendo.destroy(this.hostEl.nativeElement);
  }

}
