import { Injectable } from "@angular/core";
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Injectable()
export class ProductService {
  
  constructor(private http: HttpClient) { }
  
  public getSpreadSheetData(){
    return this.http.get("assets/SpreadSheet.json")
    // return this.http.post("http://localhost:2031/AmelioWorkflow/AmlioWeb/Common/Helper/HelperService.asmx/GetSpreadsheetData",{'engagementPkId':'9ojQaebcFEWTaZveJB18eg','questionPkIds':'d206f3c1-5ed5-43cc-8151-7e83d737c6f0'});
   
  }
}
